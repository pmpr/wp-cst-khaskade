<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d982b078a             |
    |_______________________________________|
*/
 use Pmpr\Custom\Khaskade\Khaskade; Khaskade::symcgieuakksimmu();
