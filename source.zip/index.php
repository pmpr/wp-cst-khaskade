<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa8fb98cf             |
    |_______________________________________|
*/
 use Pmpr\Custom\Khaskade\Khaskade; Khaskade::symcgieuakksimmu();
