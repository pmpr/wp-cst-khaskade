<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0b91ce2cd2             |
    |_______________________________________|
*/
 use Pmpr\Custom\Khaskade\Khaskade; Khaskade::symcgieuakksimmu();
