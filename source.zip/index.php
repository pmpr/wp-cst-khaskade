<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0ba152e203             |
    |_______________________________________|
*/
 use Pmpr\Custom\Khaskade\Khaskade; Khaskade::symcgieuakksimmu();
