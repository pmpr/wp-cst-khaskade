<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a0b31f012fd             |
    |_______________________________________|
*/
 use Pmpr\Custom\Khaskade\Khaskade; Khaskade::symcgieuakksimmu();
