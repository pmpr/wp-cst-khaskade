<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa8fb98cf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
