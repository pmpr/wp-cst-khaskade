<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d982b078a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
