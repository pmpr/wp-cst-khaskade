<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69999f63b7b19             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Khaskade\OrderCampaign\OrderCampaign; class Khaskade extends ComponentInitiator { const PREFIX = 'cst_khaskade_'; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __('Khaskade Custom', PR__CST__KHASKADE); }, Constants::sguyaymiiiiewame => Setting::class]); } public function aqyikqugcomoqqqi() { if ($this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk('sms')) { OrderCampaign::symcgieuakksimmu(); } } }
