<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69a09c81aedbf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade\OrderCampaign\Model; use Pmpr\Module\SMS\Model\Recipient as BaseClass; class Recipient extends BaseClass { const iuyuwaomgikisgww = 'campaign_id'; public function register() { $this->muuwuqssqkaieqge(__('Campaign Recipients', PR__CST__KHASKADE))->guiaswksukmgageq(__('Campaign Recipient', PR__CST__KHASKADE)); parent::register(); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::iuyuwaomgikisgww)->oowcmkiwgqgugkku()->gswweykyogmsyawy(__('Campaign', PR__CST__KHASKADE))->wuuqgaekqeymecag(Campaign::class)->jyumyyugiwwiqomk(10)); parent::uwmqacgewuauagai(); } }
