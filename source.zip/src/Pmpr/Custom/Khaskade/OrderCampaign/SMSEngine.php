<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6999aa8fb98cf             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade\OrderCampaign; use Pmpr\Module\SMS\AbstractSMS; class SMSEngine extends AbstractSMS { }
