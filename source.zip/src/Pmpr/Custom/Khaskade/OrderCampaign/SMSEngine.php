<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             69999f63b7b19             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade\OrderCampaign; use Pmpr\Module\SMS\AbstractSMS; class SMSEngine extends AbstractSMS { }
