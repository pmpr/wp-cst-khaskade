<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6998d982b078a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Khaskade\OrderCampaign; use Pmpr\Module\SMS\AbstractSMS; class SMSEngine extends AbstractSMS { }
